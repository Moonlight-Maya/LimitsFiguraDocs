local speed = 5
function events.render(delta)
	local time = world.getTime() + delta
	models.die.cube:setRot(0, time * speed, 0)
end

function pings.toggleCube(isToggled)
	models.die.cube:setVisible(isToggled)
	if isToggled == false then
		for _ = 1,200 do
			local position = player:getPos()
			position.y = position.y + 2.5
			local xSpeed = math.random() * 2 - 1
			local ySpeed = math.random() * 2 - 1
			local zSpeed = math.random() * 2 - 1
			particles:newParticle("poof"):pos(position):velocity(xSpeed, ySpeed, zSpeed)
		end
	end
	local position = player:getPos()
	sounds:playSound("minecraft:ui.toast.in", position)
end

function pings.changeCubeSpeed(scrollAmount)
	speed = speed + scrollAmount
end

local myPage = action_wheel:newPage()
local myAction = myPage:newAction()
myAction:onToggle(pings.toggleCube)
myAction:toggled(true)
myAction:onScroll(pings.changeCubeSpeed)
action_wheel:setPage(myPage)